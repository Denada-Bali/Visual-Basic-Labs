﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        TextBox1 = New TextBox()
        TextBox2 = New TextBox()
        GroupBox1 = New GroupBox()
        RadioButton5 = New RadioButton()
        RadioButton4 = New RadioButton()
        RadioButton3 = New RadioButton()
        RadioButton2 = New RadioButton()
        RadioButton1 = New RadioButton()
        GroupBox2 = New GroupBox()
        RadioButton11 = New RadioButton()
        RadioButton10 = New RadioButton()
        RadioButton9 = New RadioButton()
        RadioButton8 = New RadioButton()
        RadioButton7 = New RadioButton()
        RadioButton6 = New RadioButton()
        GroupBox3 = New GroupBox()
        RadioButton18 = New RadioButton()
        RadioButton17 = New RadioButton()
        RadioButton16 = New RadioButton()
        RadioButton15 = New RadioButton()
        RadioButton14 = New RadioButton()
        RadioButton13 = New RadioButton()
        RadioButton12 = New RadioButton()
        GroupBox4 = New GroupBox()
        CheckBox3 = New CheckBox()
        CheckBox2 = New CheckBox()
        CheckBox1 = New CheckBox()
        GroupBox5 = New GroupBox()
        RadioButton21 = New RadioButton()
        RadioButton20 = New RadioButton()
        RadioButton19 = New RadioButton()
        GroupBox6 = New GroupBox()
        CheckBox5 = New CheckBox()
        CheckBox4 = New CheckBox()
        GroupBox7 = New GroupBox()
        CheckBox8 = New CheckBox()
        CheckBox7 = New CheckBox()
        CheckBox6 = New CheckBox()
        GroupBox8 = New GroupBox()
        RadioButton25 = New RadioButton()
        RadioButton24 = New RadioButton()
        RadioButton23 = New RadioButton()
        RadioButton22 = New RadioButton()
        Button1 = New Button()
        Label1 = New Label()
        Label2 = New Label()
        Panel1 = New Panel()
        ListBox1 = New ListBox()
        GroupBox1.SuspendLayout()
        GroupBox2.SuspendLayout()
        GroupBox3.SuspendLayout()
        GroupBox4.SuspendLayout()
        GroupBox5.SuspendLayout()
        GroupBox6.SuspendLayout()
        GroupBox7.SuspendLayout()
        GroupBox8.SuspendLayout()
        SuspendLayout()
        ' 
        ' TextBox1
        ' 
        TextBox1.Location = New Point(312, 12)
        TextBox1.Name = "TextBox1"
        TextBox1.Size = New Size(58, 23)
        TextBox1.TabIndex = 0
        ' 
        ' TextBox2
        ' 
        TextBox2.Location = New Point(386, 12)
        TextBox2.Name = "TextBox2"
        TextBox2.ReadOnly = True
        TextBox2.Size = New Size(58, 23)
        TextBox2.TabIndex = 1
        ' 
        ' GroupBox1
        ' 
        GroupBox1.Controls.Add(RadioButton5)
        GroupBox1.Controls.Add(RadioButton4)
        GroupBox1.Controls.Add(RadioButton3)
        GroupBox1.Controls.Add(RadioButton2)
        GroupBox1.Controls.Add(RadioButton1)
        GroupBox1.Location = New Point(22, 50)
        GroupBox1.Name = "GroupBox1"
        GroupBox1.Size = New Size(171, 121)
        GroupBox1.TabIndex = 3
        GroupBox1.TabStop = False
        GroupBox1.Text = "SAT"' 
        ' RadioButton5
        ' 
        RadioButton5.AutoSize = True
        RadioButton5.Location = New Point(24, 96)
        RadioButton5.Name = "RadioButton5"
        RadioButton5.Size = New Size(101, 19)
        RadioButton5.TabIndex = 4
        RadioButton5.TabStop = True
        RadioButton5.Text = "1360-1600 [12]"
        RadioButton5.UseVisualStyleBackColor = True
        ' 
        ' RadioButton4
        ' 
        RadioButton4.AutoSize = True
        RadioButton4.Location = New Point(24, 75)
        RadioButton4.Name = "RadioButton4"
        RadioButton4.Size = New Size(101, 19)
        RadioButton4.TabIndex = 3
        RadioButton4.TabStop = True
        RadioButton4.Text = "1200-1350 [11]"
        RadioButton4.UseVisualStyleBackColor = True
        ' 
        ' RadioButton3
        ' 
        RadioButton3.AutoSize = True
        RadioButton3.Location = New Point(23, 57)
        RadioButton3.Name = "RadioButton3"
        RadioButton3.Size = New Size(101, 19)
        RadioButton3.TabIndex = 2
        RadioButton3.TabStop = True
        RadioButton3.Text = "1010-1190 [10]"
        RadioButton3.UseVisualStyleBackColor = True
        ' 
        ' RadioButton2
        ' 
        RadioButton2.AutoSize = True
        RadioButton2.Location = New Point(23, 34)
        RadioButton2.Name = "RadioButton2"
        RadioButton2.Size = New Size(89, 19)
        RadioButton2.TabIndex = 1
        RadioButton2.TabStop = True
        RadioButton2.Text = "930-1000 [6]"
        RadioButton2.UseVisualStyleBackColor = True
        ' 
        ' RadioButton1
        ' 
        RadioButton1.AutoSize = True
        RadioButton1.Location = New Point(24, 16)
        RadioButton1.Name = "RadioButton1"
        RadioButton1.Size = New Size(83, 19)
        RadioButton1.TabIndex = 0
        RadioButton1.TabStop = True
        RadioButton1.Text = "400-920 [0]"
        RadioButton1.UseVisualStyleBackColor = True
        ' 
        ' GroupBox2
        ' 
        GroupBox2.Controls.Add(RadioButton11)
        GroupBox2.Controls.Add(RadioButton10)
        GroupBox2.Controls.Add(RadioButton9)
        GroupBox2.Controls.Add(RadioButton8)
        GroupBox2.Controls.Add(RadioButton7)
        GroupBox2.Controls.Add(RadioButton6)
        GroupBox2.Location = New Point(218, 50)
        GroupBox2.Name = "GroupBox2"
        GroupBox2.Size = New Size(170, 121)
        GroupBox2.TabIndex = 4
        GroupBox2.TabStop = False
        GroupBox2.Text = "High School Quality"' 
        ' RadioButton11
        ' 
        RadioButton11.AutoSize = True
        RadioButton11.Location = New Point(94, 78)
        RadioButton11.Name = "RadioButton11"
        RadioButton11.Size = New Size(54, 19)
        RadioButton11.TabIndex = 5
        RadioButton11.TabStop = True
        RadioButton11.Text = "5 [10]"
        RadioButton11.UseVisualStyleBackColor = True
        ' 
        ' RadioButton10
        ' 
        RadioButton10.AutoSize = True
        RadioButton10.Location = New Point(94, 55)
        RadioButton10.Name = "RadioButton10"
        RadioButton10.Size = New Size(48, 19)
        RadioButton10.TabIndex = 4
        RadioButton10.TabStop = True
        RadioButton10.Text = "4 [8]"
        RadioButton10.UseVisualStyleBackColor = True
        ' 
        ' RadioButton9
        ' 
        RadioButton9.AutoSize = True
        RadioButton9.Location = New Point(95, 30)
        RadioButton9.Name = "RadioButton9"
        RadioButton9.Size = New Size(48, 19)
        RadioButton9.TabIndex = 3
        RadioButton9.TabStop = True
        RadioButton9.Text = "3 [6]"
        RadioButton9.UseVisualStyleBackColor = True
        ' 
        ' RadioButton8
        ' 
        RadioButton8.AutoSize = True
        RadioButton8.Location = New Point(24, 75)
        RadioButton8.Name = "RadioButton8"
        RadioButton8.Size = New Size(48, 19)
        RadioButton8.TabIndex = 2
        RadioButton8.TabStop = True
        RadioButton8.Text = "2 [4]"
        RadioButton8.UseVisualStyleBackColor = True
        ' 
        ' RadioButton7
        ' 
        RadioButton7.AutoSize = True
        RadioButton7.Location = New Point(24, 55)
        RadioButton7.Name = "RadioButton7"
        RadioButton7.Size = New Size(48, 19)
        RadioButton7.TabIndex = 1
        RadioButton7.TabStop = True
        RadioButton7.Text = "1 [2]"
        RadioButton7.UseVisualStyleBackColor = True
        ' 
        ' RadioButton6
        ' 
        RadioButton6.AutoSize = True
        RadioButton6.Location = New Point(24, 30)
        RadioButton6.Name = "RadioButton6"
        RadioButton6.Size = New Size(48, 19)
        RadioButton6.TabIndex = 0
        RadioButton6.TabStop = True
        RadioButton6.Text = "0 [0]"
        RadioButton6.UseVisualStyleBackColor = True
        ' 
        ' GroupBox3
        ' 
        GroupBox3.Controls.Add(RadioButton18)
        GroupBox3.Controls.Add(RadioButton17)
        GroupBox3.Controls.Add(RadioButton16)
        GroupBox3.Controls.Add(RadioButton15)
        GroupBox3.Controls.Add(RadioButton14)
        GroupBox3.Controls.Add(RadioButton13)
        GroupBox3.Controls.Add(RadioButton12)
        GroupBox3.Location = New Point(419, 50)
        GroupBox3.Name = "GroupBox3"
        GroupBox3.Size = New Size(157, 121)
        GroupBox3.TabIndex = 5
        GroupBox3.TabStop = False
        GroupBox3.Text = "Difficulty of Curriculum"' 
        ' RadioButton18
        ' 
        RadioButton18.AutoSize = True
        RadioButton18.Location = New Point(88, 78)
        RadioButton18.Name = "RadioButton18"
        RadioButton18.Size = New Size(48, 19)
        RadioButton18.TabIndex = 6
        RadioButton18.TabStop = True
        RadioButton18.Text = "4 [8]"
        RadioButton18.UseVisualStyleBackColor = True
        ' 
        ' RadioButton17
        ' 
        RadioButton17.AutoSize = True
        RadioButton17.Location = New Point(88, 50)
        RadioButton17.Name = "RadioButton17"
        RadioButton17.Size = New Size(48, 19)
        RadioButton17.TabIndex = 5
        RadioButton17.TabStop = True
        RadioButton17.Text = "3 [6]"
        RadioButton17.UseVisualStyleBackColor = True
        ' 
        ' RadioButton16
        ' 
        RadioButton16.AutoSize = True
        RadioButton16.Location = New Point(88, 25)
        RadioButton16.Name = "RadioButton16"
        RadioButton16.Size = New Size(48, 19)
        RadioButton16.TabIndex = 4
        RadioButton16.TabStop = True
        RadioButton16.Text = "2 [4]"
        RadioButton16.UseVisualStyleBackColor = True
        ' 
        ' RadioButton15
        ' 
        RadioButton15.AutoSize = True
        RadioButton15.Location = New Point(19, 96)
        RadioButton15.Name = "RadioButton15"
        RadioButton15.Size = New Size(48, 19)
        RadioButton15.TabIndex = 3
        RadioButton15.TabStop = True
        RadioButton15.Text = "1 [2]"
        RadioButton15.UseVisualStyleBackColor = True
        ' 
        ' RadioButton14
        ' 
        RadioButton14.AutoSize = True
        RadioButton14.Location = New Point(19, 75)
        RadioButton14.Name = "RadioButton14"
        RadioButton14.Size = New Size(48, 19)
        RadioButton14.TabIndex = 2
        RadioButton14.TabStop = True
        RadioButton14.Text = "0 [0]"
        RadioButton14.UseVisualStyleBackColor = True
        ' 
        ' RadioButton13
        ' 
        RadioButton13.AutoSize = True
        RadioButton13.Location = New Point(19, 50)
        RadioButton13.Name = "RadioButton13"
        RadioButton13.Size = New Size(58, 19)
        RadioButton13.TabIndex = 1
        RadioButton13.TabStop = True
        RadioButton13.Text = "-1 [-2]"
        RadioButton13.UseVisualStyleBackColor = True
        ' 
        ' RadioButton12
        ' 
        RadioButton12.AutoSize = True
        RadioButton12.Location = New Point(19, 25)
        RadioButton12.Name = "RadioButton12"
        RadioButton12.Size = New Size(58, 19)
        RadioButton12.TabIndex = 0
        RadioButton12.TabStop = True
        RadioButton12.Text = "-2 [-4]"
        RadioButton12.UseVisualStyleBackColor = True
        ' 
        ' GroupBox4
        ' 
        GroupBox4.Controls.Add(CheckBox3)
        GroupBox4.Controls.Add(CheckBox2)
        GroupBox4.Controls.Add(CheckBox1)
        GroupBox4.Location = New Point(54, 216)
        GroupBox4.Name = "GroupBox4"
        GroupBox4.Size = New Size(200, 100)
        GroupBox4.TabIndex = 6
        GroupBox4.TabStop = False
        GroupBox4.Text = "Geography"' 
        ' CheckBox3
        ' 
        CheckBox3.AutoSize = True
        CheckBox3.Location = New Point(13, 77)
        CheckBox3.Name = "CheckBox3"
        CheckBox3.Size = New Size(165, 19)
        CheckBox3.TabIndex = 2
        CheckBox3.Text = "Underrepresented state [2]"
        CheckBox3.UseVisualStyleBackColor = True
        ' 
        ' CheckBox2
        ' 
        CheckBox2.AutoSize = True
        CheckBox2.Location = New Point(13, 49)
        CheckBox2.Name = "CheckBox2"
        CheckBox2.Size = New Size(205, 19)
        CheckBox2.TabIndex = 1
        CheckBox2.Text = "Underrepresented state county [6]"
        CheckBox2.UseVisualStyleBackColor = True
        ' 
        ' CheckBox1
        ' 
        CheckBox1.AutoSize = True
        CheckBox1.Location = New Point(13, 24)
        CheckBox1.Name = "CheckBox1"
        CheckBox1.Size = New Size(120, 19)
        CheckBox1.TabIndex = 0
        CheckBox1.Text = "State resident [10]"
        CheckBox1.TextAlign = ContentAlignment.MiddleCenter
        CheckBox1.UseVisualStyleBackColor = True
        ' 
        ' GroupBox5
        ' 
        GroupBox5.Controls.Add(RadioButton21)
        GroupBox5.Controls.Add(RadioButton20)
        GroupBox5.Controls.Add(RadioButton19)
        GroupBox5.Location = New Point(296, 216)
        GroupBox5.Name = "GroupBox5"
        GroupBox5.Size = New Size(200, 100)
        GroupBox5.TabIndex = 7
        GroupBox5.TabStop = False
        GroupBox5.Text = "Essay"' 
        ' RadioButton21
        ' 
        RadioButton21.AutoSize = True
        RadioButton21.Location = New Point(17, 73)
        RadioButton21.Name = "RadioButton21"
        RadioButton21.Size = New Size(108, 19)
        RadioButton21.TabIndex = 2
        RadioButton21.TabStop = True
        RadioButton21.Text = "Outstanding [3]"
        RadioButton21.UseVisualStyleBackColor = True
        ' 
        ' RadioButton20
        ' 
        RadioButton20.AutoSize = True
        RadioButton20.Location = New Point(16, 48)
        RadioButton20.Name = "RadioButton20"
        RadioButton20.Size = New Size(89, 19)
        RadioButton20.TabIndex = 1
        RadioButton20.TabStop = True
        RadioButton20.Text = "Excellent [2]"
        RadioButton20.UseVisualStyleBackColor = True
        ' 
        ' RadioButton19
        ' 
        RadioButton19.AutoSize = True
        RadioButton19.Location = New Point(17, 23)
        RadioButton19.Name = "RadioButton19"
        RadioButton19.Size = New Size(96, 19)
        RadioButton19.TabIndex = 0
        RadioButton19.TabStop = True
        RadioButton19.Text = "Very Good [1]"
        RadioButton19.UseVisualStyleBackColor = True
        ' 
        ' GroupBox6
        ' 
        GroupBox6.Controls.Add(CheckBox5)
        GroupBox6.Controls.Add(CheckBox4)
        GroupBox6.Location = New Point(54, 338)
        GroupBox6.Name = "GroupBox6"
        GroupBox6.Size = New Size(200, 100)
        GroupBox6.TabIndex = 8
        GroupBox6.TabStop = False
        GroupBox6.Text = "Alumni"' 
        ' CheckBox5
        ' 
        CheckBox5.AutoSize = True
        CheckBox5.Location = New Point(13, 63)
        CheckBox5.Name = "CheckBox5"
        CheckBox5.Size = New Size(206, 19)
        CheckBox5.TabIndex = 1
        CheckBox5.Text = "Other (grandparents, siblings) [11]"
        CheckBox5.UseVisualStyleBackColor = True
        ' 
        ' CheckBox4
        ' 
        CheckBox4.AutoSize = True
        CheckBox4.Location = New Point(13, 26)
        CheckBox4.Name = "CheckBox4"
        CheckBox4.Size = New Size(197, 19)
        CheckBox4.TabIndex = 0
        CheckBox4.Text = "Legacy (parents, stepparents) [4]"
        CheckBox4.UseVisualStyleBackColor = True
        ' 
        ' GroupBox7
        ' 
        GroupBox7.Controls.Add(CheckBox8)
        GroupBox7.Controls.Add(CheckBox7)
        GroupBox7.Controls.Add(CheckBox6)
        GroupBox7.Location = New Point(296, 338)
        GroupBox7.Name = "GroupBox7"
        GroupBox7.Size = New Size(200, 100)
        GroupBox7.TabIndex = 9
        GroupBox7.TabStop = False
        GroupBox7.Text = "Leadership and Service"' 
        ' CheckBox8
        ' 
        CheckBox8.AutoSize = True
        CheckBox8.Location = New Point(21, 75)
        CheckBox8.Name = "CheckBox8"
        CheckBox8.Size = New Size(88, 19)
        CheckBox8.TabIndex = 2
        CheckBox8.Text = "National [5]"
        CheckBox8.UseVisualStyleBackColor = True
        ' 
        ' CheckBox7
        ' 
        CheckBox7.AutoSize = True
        CheckBox7.Location = New Point(22, 50)
        CheckBox7.Name = "CheckBox7"
        CheckBox7.Size = New Size(89, 19)
        CheckBox7.TabIndex = 1
        CheckBox7.Text = "Regional [2]"
        CheckBox7.UseVisualStyleBackColor = True
        ' 
        ' CheckBox6
        ' 
        CheckBox6.AutoSize = True
        CheckBox6.Location = New Point(22, 25)
        CheckBox6.Name = "CheckBox6"
        CheckBox6.Size = New Size(69, 19)
        CheckBox6.TabIndex = 0
        CheckBox6.Text = "State [1]"
        CheckBox6.UseVisualStyleBackColor = True
        ' 
        ' GroupBox8
        ' 
        GroupBox8.Controls.Add(RadioButton25)
        GroupBox8.Controls.Add(RadioButton24)
        GroupBox8.Controls.Add(RadioButton23)
        GroupBox8.Controls.Add(RadioButton22)
        GroupBox8.Location = New Point(536, 216)
        GroupBox8.Name = "GroupBox8"
        GroupBox8.Size = New Size(200, 222)
        GroupBox8.TabIndex = 10
        GroupBox8.TabStop = False
        GroupBox8.Text = "Miscellaneouse"' 
        ' RadioButton25
        ' 
        RadioButton25.AutoSize = True
        RadioButton25.Location = New Point(12, 147)
        RadioButton25.Name = "RadioButton25"
        RadioButton25.Size = New Size(151, 19)
        RadioButton25.TabIndex = 3
        RadioButton25.TabStop = True
        RadioButton25.Text = "Provost's discretion [20]"
        RadioButton25.UseVisualStyleBackColor = True
        ' 
        ' RadioButton24
        ' 
        RadioButton24.AutoSize = True
        RadioButton24.Location = New Point(12, 110)
        RadioButton24.Name = "RadioButton24"
        RadioButton24.Size = New Size(148, 19)
        RadioButton24.TabIndex = 2
        RadioButton24.TabStop = True
        RadioButton24.Text = "Scholarship athlete [20]"
        RadioButton24.UseVisualStyleBackColor = True
        ' 
        ' RadioButton23
        ' 
        RadioButton23.AutoSize = True
        RadioButton23.Location = New Point(12, 76)
        RadioButton23.Name = "RadioButton23"
        RadioButton23.Size = New Size(122, 19)
        RadioButton23.TabIndex = 1
        RadioButton23.TabStop = True
        RadioButton23.Text = "Men in nursing [5]"
        RadioButton23.UseVisualStyleBackColor = True
        ' 
        ' RadioButton22
        ' 
        RadioButton22.AutoSize = True
        RadioButton22.Location = New Point(12, 37)
        RadioButton22.Name = "RadioButton22"
        RadioButton22.Size = New Size(203, 19)
        RadioButton22.TabIndex = 0
        RadioButton22.TabStop = True
        RadioButton22.Text = "Socioeconomic disadvantage [20]"
        RadioButton22.UseVisualStyleBackColor = True
        ' 
        ' Button1
        ' 
        Button1.Location = New Point(619, 12)
        Button1.Name = "Button1"
        Button1.Size = New Size(149, 23)
        Button1.TabIndex = 11
        Button1.Text = "Calculate Total Score"
        Button1.UseVisualStyleBackColor = True
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Location = New Point(242, 15)
        Label1.Name = "Label1"
        Label1.Size = New Size(64, 15)
        Label1.TabIndex = 12
        Label1.Text = "GPA Score:"' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Font = New Font("Segoe UI", 9F, FontStyle.Italic, GraphicsUnit.Point)
        Label2.Location = New Point(356, 183)
        Label2.Name = "Label2"
        Label2.Size = New Size(122, 15)
        Label2.TabIndex = 13
        Label2.Text = "Maximum of 40 Points"' 
        ' Panel1
        ' 
        Panel1.BorderStyle = BorderStyle.FixedSingle
        Panel1.Location = New Point(43, 177)
        Panel1.Name = "Panel1"
        Panel1.Size = New Size(715, 3)
        Panel1.TabIndex = 14
        ' 
        ' ListBox1
        ' 
        ListBox1.FormattingEnabled = True
        ListBox1.ItemHeight = 15
        ListBox1.Location = New Point(619, 55)
        ListBox1.Name = "ListBox1"
        ListBox1.Size = New Size(149, 64)
        ListBox1.TabIndex = 15
        ' 
        ' Form1
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(800, 450)
        Controls.Add(ListBox1)
        Controls.Add(Panel1)
        Controls.Add(Label2)
        Controls.Add(Label1)
        Controls.Add(Button1)
        Controls.Add(GroupBox8)
        Controls.Add(GroupBox7)
        Controls.Add(GroupBox6)
        Controls.Add(GroupBox5)
        Controls.Add(GroupBox4)
        Controls.Add(GroupBox3)
        Controls.Add(GroupBox2)
        Controls.Add(GroupBox1)
        Controls.Add(TextBox2)
        Controls.Add(TextBox1)
        Name = "Form1"
        Text = "University Admissions Point System"
        GroupBox1.ResumeLayout(False)
        GroupBox1.PerformLayout()
        GroupBox2.ResumeLayout(False)
        GroupBox2.PerformLayout()
        GroupBox3.ResumeLayout(False)
        GroupBox3.PerformLayout()
        GroupBox4.ResumeLayout(False)
        GroupBox4.PerformLayout()
        GroupBox5.ResumeLayout(False)
        GroupBox5.PerformLayout()
        GroupBox6.ResumeLayout(False)
        GroupBox6.PerformLayout()
        GroupBox7.ResumeLayout(False)
        GroupBox7.PerformLayout()
        GroupBox8.ResumeLayout(False)
        GroupBox8.PerformLayout()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents TextBox2 As TextBox
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents GroupBox3 As GroupBox
    Friend WithEvents GroupBox4 As GroupBox
    Friend WithEvents GroupBox5 As GroupBox
    Friend WithEvents GroupBox6 As GroupBox
    Friend WithEvents GroupBox7 As GroupBox
    Friend WithEvents GroupBox8 As GroupBox
    Friend WithEvents Button1 As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Panel1 As Panel
    Friend WithEvents RadioButton5 As RadioButton
    Friend WithEvents RadioButton4 As RadioButton
    Friend WithEvents RadioButton3 As RadioButton
    Friend WithEvents RadioButton2 As RadioButton
    Friend WithEvents RadioButton1 As RadioButton
    Friend WithEvents RadioButton11 As RadioButton
    Friend WithEvents RadioButton10 As RadioButton
    Friend WithEvents RadioButton9 As RadioButton
    Friend WithEvents RadioButton8 As RadioButton
    Friend WithEvents RadioButton7 As RadioButton
    Friend WithEvents RadioButton6 As RadioButton
    Friend WithEvents RadioButton18 As RadioButton
    Friend WithEvents RadioButton17 As RadioButton
    Friend WithEvents RadioButton16 As RadioButton
    Friend WithEvents RadioButton15 As RadioButton
    Friend WithEvents RadioButton14 As RadioButton
    Friend WithEvents RadioButton13 As RadioButton
    Friend WithEvents RadioButton12 As RadioButton
    Friend WithEvents CheckBox3 As CheckBox
    Friend WithEvents CheckBox2 As CheckBox
    Friend WithEvents CheckBox1 As CheckBox
    Friend WithEvents RadioButton21 As RadioButton
    Friend WithEvents RadioButton20 As RadioButton
    Friend WithEvents RadioButton19 As RadioButton
    Friend WithEvents CheckBox5 As CheckBox
    Friend WithEvents CheckBox4 As CheckBox
    Friend WithEvents CheckBox8 As CheckBox
    Friend WithEvents CheckBox7 As CheckBox
    Friend WithEvents CheckBox6 As CheckBox
    Friend WithEvents RadioButton25 As RadioButton
    Friend WithEvents RadioButton24 As RadioButton
    Friend WithEvents RadioButton23 As RadioButton
    Friend WithEvents RadioButton22 As RadioButton
    Friend WithEvents ListBox1 As ListBox
End Class
